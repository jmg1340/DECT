export function mutImportarSpectralink ( state, payload ) {
	state.arrSpectralink = payload.arr
}
export function mutImportarDTIC ( state, payload ) {
	state.arrInventariDTIC = payload.arr
}
export function mutImportarStock ( state, payload ) {
	state.arrStock = payload.arr
}
