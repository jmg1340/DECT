export default function () {
  return {
		arrSpectralink: [],
		arrStock: [],
		arrInventariDTIC: []
  }
}
