<template>
		<q-page class="flex flex-center">
		
			<img class=""
				src="~assets/quasar-logo-full.svg"
			/>
		


  </q-page>
</template>

<script>
export default {
  name: 'PageIndex'
}
</script>
